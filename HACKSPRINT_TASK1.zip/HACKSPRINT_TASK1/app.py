import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import glob, os

# -----------------------------
# PAGE CONFIG
# -----------------------------
st.set_page_config(
    page_title="Product Loss Analytics Dashboard",
    layout="wide"
)

st.title("📦 Product Loss Analytics Dashboard")
st.markdown(
    """
    End-to-end analytical framework demonstrating **Data Engineering, EDA,
    Statistical Analysis, and Business Insights**.
    """
)

# -----------------------------
# DATA INGESTION PIPELINE
# -----------------------------
@st.cache_data
def load_and_integrate_data():
    DATA_FOLDER = "Track1_Analytics_Dataset"
    csv_files = glob.glob(os.path.join(DATA_FOLDER, "*.csv"))
    df_list = [pd.read_csv(file) for file in csv_files]
    df = pd.concat(df_list, ignore_index=True)
    return df

df = load_and_integrate_data()

# -----------------------------
# DATA ENGINEERING & PREPARATION
# -----------------------------
st.header("1️⃣ Data Engineering & Preparation")

col1, col2, col3 = st.columns(3)
col1.metric("Total Records", df.shape[0])
col2.metric("Unique Products", df["Item Code"].nunique())
col3.metric("Average Loss Rate (%)", f"{df['Loss Rate (%)'].mean():.2f}")

st.subheader("Data Quality Checks")
st.write("Missing Values")
st.dataframe(df.isnull().sum())

df = df.drop_duplicates()

# -----------------------------
# OUTLIER DETECTION (IQR)
# -----------------------------
Q1 = df["Loss Rate (%)"].quantile(0.25)
Q3 = df["Loss Rate (%)"].quantile(0.75)
IQR = Q3 - Q1
upper_threshold = Q3 + 1.5 * IQR

df["High_Loss_Flag"] = df["Loss Rate (%)"] > upper_threshold

st.write(f"High Loss Threshold: **{upper_threshold:.2f}%**")
st.write(f"High Loss Products: **{df['High_Loss_Flag'].sum()}**")

# -----------------------------
# EXPLORATORY DATA ANALYSIS
# -----------------------------
st.header("2️⃣ Exploratory Data Analysis")

col1, col2 = st.columns(2)

# -----------------------------
# Histogram: Loss Rate Distribution
# -----------------------------
with col1:
    st.subheader("Loss Rate Distribution")
    fig, ax = plt.subplots()
    ax.hist(df["Loss Rate (%)"].dropna(), bins=30)
    ax.set_xlabel("Loss Rate (%)")
    ax.set_ylabel("Count")
    ax.set_title("Histogram of Loss Rate")
    st.pyplot(fig)

# -----------------------------
# Box Plot: Outlier Detection
# -----------------------------
with col2:
    st.subheader("Box Plot (Outlier Detection)")
    fig, ax = plt.subplots()
    ax.boxplot(df["Loss Rate (%)"].dropna(), vert=False)
    ax.set_xlabel("Loss Rate (%)")
    ax.set_title("Box Plot of Loss Rate")
    st.pyplot(fig)

# -----------------------------
# Statistical Summary
# -----------------------------
st.subheader("Statistical Summary")

stats_df = df["Loss Rate (%)"].describe().to_frame(name="Value")
st.dataframe(stats_df)

st.write(
    "**Skewness:**",
    round(df["Loss Rate (%)"].skew(), 2)
)


# -----------------------------
# TOP LOSS CONTRIBUTORS
# -----------------------------
st.header("High Impact Loss Contributors")

top_n = st.slider("Select Top N Products", 5, 20, 10)

top_loss = df.sort_values("Loss Rate (%)", ascending=False).head(top_n)

st.dataframe(top_loss)

fig, ax = plt.subplots()
ax.barh(top_loss["Item Name"], top_loss["Loss Rate (%)"])
ax.set_xlabel("Loss Rate (%)")
ax.invert_yaxis()
st.pyplot(fig)

# -----------------------------
# HYPOTHESIS & INSIGHTS
# -----------------------------
st.header("3️⃣ Strategic Insights & Visualization")

st.markdown(
    """
    **Hypothesis 1:**  
    A small percentage of products contributes disproportionately to total loss.

    **Hypothesis 2:**  
    High-loss products represent consistent operational inefficiencies.
    """
)

st.subheader("Key Insights")
st.markdown(
    """
    - Loss distribution is right-skewed
    - ~10–15% of products drive majority of loss
    - High-loss products are persistent and predictable
    """
)

# -----------------------------
# BUSINESS RECOMMENDATIONS
# -----------------------------
st.subheader("Business Recommendations")

st.markdown(
    """
    ✅ Prioritize audits for high-loss products  
    ✅ Improve handling and storage processes  
    ✅ Review supplier performance  
    ✅ Implement continuous loss monitoring  
    """
)

# -----------------------------
# EXECUTIVE SUMMARY
# -----------------------------
st.header("📌 Executive Summary")

st.info(
    f"""
    Out of {df.shape[0]} products analyzed,
    {df['High_Loss_Flag'].sum()} products exceed the acceptable loss threshold.
    Targeted interventions on these items can significantly reduce overall losses.
    """
)

st.markdown("---")

